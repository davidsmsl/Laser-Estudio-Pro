// Soporte ajustable para final de carrera mecánico (módulo con microinterruptor)
// Two Trees TTS-55 / TTS-55 Pro / TTS-10 — perfil de aluminio con ranura en T.
// Abra en OpenSCAD (gratis), cambie las medidas de abajo y exporte con F6 → STL.
// Medidas en mm.

L = 38;            // largo de la base (a lo largo del riel)
W = 22;            // ancho de la base (cara del perfil: 20 mm)
T = 5;             // grosor de la base
e = 4;             // grosor de la placa vertical
alto_placa = 32;   // altura de la placa por encima de la base
guia = true;       // lengüeta que entra en la ranura del perfil
guia_ancho = 5.8;  // ancho de la ranura del perfil menos 0,2 mm (ranura de 6 mm → 5,8)
guia_alto = 1.6;   // profundidad de la lengüeta
tornillo = 4.5;    // agujero para tornillo al perfil (M4 = 4,5 · M3 = 3,4)
cabeza = 8.8;      // ancho del alojamiento de la cabeza del tornillo
espejo = false;    // true = placa del otro lado (para montarlo al lado contrario)

$fn = 48;
H = T + alto_placa;
yc = e + (W - e) / 2;

module oblongo_z(x0, x1, y, r, z0, h) {
  hull() { translate([x0, y, z0]) cylinder(r = r, h = h); translate([x1, y, z0]) cylinder(r = r, h = h); }
}
module oblongo_y(x0, x1, zc, r) {
  hull() { translate([x0, -1, zc]) rotate([-90, 0, 0]) cylinder(r = r, h = e + 2);
           translate([x1, -1, zc]) rotate([-90, 0, 0]) cylinder(r = r, h = e + 2); }
}
module soporte() {
  difference() {
    union() {
      cube([L, W, T]);                                   // base
      cube([L, e, H]);                                   // placa vertical
      hull() for (x = [0, 4]) {                          // refuerzo
        translate([x, e, T]) cube([0.01, W - 3 - e, 0.01]);
        translate([x, e, T]) cube([0.01, 0.01, 18]);
      }
      if (guia) translate([0, yc - guia_ancho / 2, -guia_alto]) cube([L, guia_ancho, guia_alto]);
    }
    oblongo_z(12, 26, yc, tornillo / 2, -guia_alto - 1, T + guia_alto + 2);   // ranura de fijación (±7 mm)
    oblongo_z(12, 26, yc, cabeza / 2, T - 2, 20);                            // cabeza del tornillo
    for (zc = [T + 9, T + 21]) oblongo_y(10, 28, zc, 1.7);                   // ranuras M3 del módulo
    for (xc = [4, 34]) translate([xc - 1.3, -1, T + 5]) cube([2.6, e + 2, 21]); // ventanas para bridas
  }
}
if (espejo) mirror([0, 1, 0]) soporte(); else soporte();

// Percutor opcional: taco que se atornilla al carro/bloque si éste no alcanza la palanca
// translate([0, 40, 0]) difference() { cube([24, 16, 6]); oblongo_z(6, 18, 8, 1.7, -1, 8); oblongo_z(6, 18, 8, 3.2, 3.5, 4); }
